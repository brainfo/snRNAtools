
from setuptools import setup
  
setup(
    name='temporary_projects',
    version='0.1',
    description='A Python package path for project usage',
    author='Hong Jiang',
    author_email='scilavisher@gmail.com',
    packages=['gene_level', 'sc_utils'],
)