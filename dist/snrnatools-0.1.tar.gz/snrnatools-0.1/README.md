#snRNAtools
This is actually for general omics analysis where
## gene level analysis
- Plot the bar output from gene ontology enrichment analysis
- Network analysis given any edge list
## scanpy support
For another snakemake easier evoke of a snRNA-seq pipeline using scanpy
